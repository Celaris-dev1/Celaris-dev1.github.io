# Pricing

Proof is open core. Capturing evidence and proving it later — `capture`, `manifest`, `verify`,
`revalidate` (on demand), `report` (HTML/JSON), `prove`/`verify-inclusion`, key rotation and
revocation, and a single-org `proof serve` — is free, forever, no license required, at any
crawl volume. See the README's "Built vs roadmap" and LICENSING sections for exactly what
that covers.

A small set of features on top of that — signed clean-ingestion certificates, PDF export,
scheduled revalidation, and the publisher portal's multi-org/tenant machinery, configurable
retention tiers and legal holds — require a paid, offline license key. Nothing is ever
deleted or hidden when a license lapses or was never installed: those specific features just
turn off (or, briefly, keep working with a warning — see "Grace period" below) until a valid
license is present again.

## Community — free

- `capture`, `manifest`, `verify`, `revalidate` (one-shot), `report` (HTML/JSON), `prove` /
  `verify-inclusion`
- Key rotation and revocation (`proof keys ...`)
- The default retention tier (90 days, fixed)
- `proof serve`'s single bootstrap org: reports/certs/runs API, ingest API, RBAC roles
- Everything in "Built" in the README not listed below

## Starter — $99 / month, or $990 / year

Unlocks, on top of Community:

- **`proof certify`.** Signed clean-ingestion certificates.
- **PDF export.** `report --format pdf` and `certify --pdf`.

## Pro — $299 / month, or $2,990 / year

Unlocks everything in Starter, plus the rest of this list:

- **`proof certify`.** Signed clean-ingestion certificates bundling a run's verdict, chain
  segment and per-URL Merkle inclusion proofs into a portable, offline-verifiable bundle.
- **PDF export.** `report --format pdf` and `certify --pdf` / `certificate ... --pdf`, with the
  signed JSON embedded as a verifiable attachment.
- **`proof watch`.** Scheduled re-validation of historical captures against today's signals,
  recording drift as a signed manifest.
- **Configurable retention (up to 1 year).** The `pro` retention tier.

## Enterprise — $15,000–$50,000 / year (contact sales)

Everything in Pro, plus:

- **Portal multi-org/tenant.** Provisioning more than one org on a `proof serve` instance
  (`POST /v1/orgs` beyond the bootstrap org) — multiple crawling orgs and/or publisher orgs on
  one deployment, each with the same strict tenant isolation as Community's single org.
- **Extended retention (up to 7 years).** The `enterprise` retention tier.
- **Legal holds.** `proof hold add|list|remove` — pin captures against eviction regardless of
  retention policy.
- Custom seat counts, multi-year terms, and support SLAs — contact sales.

Licensed per organization; seats/volume are a soft cap — going over never locks anyone out,
Proof just logs a reminder to true up (see `license.ts`'s `seatWarning`).

## How licensing works

A license is a small JSON document (customer, edition, features, seats, issued/expiry dates)
signed with Ed25519 and handed to you as one base64url token:
`base64url(payload) + "." + base64url(signature)`. Set it via `PROOF_LICENSE` (the token
itself) or `PROOF_LICENSE_FILE` (a path to a file holding it). Verification is entirely
offline: the token is checked against a vendor public key compiled into the build. There is
no phone-home, no activation server, and no telemetry — this works in air-gapped environments.

- `node dist/cli.js license show [--json]` — current state, customer, edition, features,
  seats, expiry.
- `node dist/cli.js license verify <token|file>` — verify a token offline and print what it
  grants.

**Grace period.** A license that has expired keeps unlocking its features, with a loud
warning, for 14 days — so a delayed renewal doesn't interrupt anyone's workflow. After that
it reads as expired and those features turn off (Community features are unaffected).

**Tampered or invalid tokens** are treated exactly like no license at all (Community), with a
warning logged — Proof fails safe, never open, on a bad token, but it never fails your build
over one either.

**A gated CLI command** fails with a clear message and a non-zero exit code (never a crash).
**A gated HTTP feature** (e.g. `proof serve` provisioning a second org, or the publisher
portal's multi-org query paths) responds `402 Payment Required` with a small JSON body naming
the feature and the edition that would unlock it.

See the README's LICENSING section for how a vendor issues keys with `scripts/licensegen.ts`,
and for the security reasoning behind why a release build never trusts the repo's checked-in
public dev key.
