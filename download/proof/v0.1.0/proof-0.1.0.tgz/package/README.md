# Proof — crawl provenance & licensing compliance

Proof is the receipt layer for crawling. At fetch time it records what **robots.txt**, **Cloudflare Content Signals**, **X-Robots-Tag** and the page's **license** said, and which **bot identity** was presented. Each crawl run is sealed into an **Ed25519-signed manifest**, hash-chained to the one before it, so the whole history is tamper-evident. Later you can **re-validate** old captures against the signals in effect today and get a report of any drift.

It is a TypeScript library, a `fetch` hook for Discover-style crawlers, and a CLI.

## Setup

Requirements: Node.js 22+ and npm. Postgres 16 is optional (otherwise a JSONL file store).

```sh
scripts/setup.sh            # check prerequisites, build, create the database on local Postgres, write .env
scripts/setup.sh --docker   # same, but start Postgres with docker compose
scripts/setup.sh --no-db    # build only
set -a; . ./.env; set +a    # load the generated config into your shell
```

The script builds `dist/` (run with `node dist/cli.js`), creates the `proof` database if Postgres is reachable
(override the admin connection with `PG_ADMIN_URL`), and writes a `.env` (mode 0600, gitignored)
with freshly generated tokens and keys. It is safe to re-run: an existing `.env` or database
is never overwritten. It finishes by printing the commands to start Proof.

## Quickstart

```bash
npm ci && npm run build
node dist/cli.js capture https://example.com/ https://example.com/about --run demo --seal
node dist/cli.js verify
node dist/cli.js revalidate --run demo
node dist/cli.js report --run demo --out demo.html      # self-contained HTML; print → PDF
node dist/cli.js report --run demo --format json         # machine-readable
```

Storage: set `PROOF_DATABASE_URL=postgres://…` for Postgres. Otherwise Proof uses an append-only JSONL file store in `PROOF_DATA_DIR` (default `./.proof`).
Signing key: `PROOF_SIGNING_KEY` (PKCS#8 PEM). Otherwise a key is created on first use at `$PROOF_KEY_DIR/proof-ed25519.pem` (default `.proof/keys`).

Portal store (`proof serve`'s orgs/tokens/domains/opt-ins/audit log): also follows `PROOF_DATABASE_URL` (a `PostgresPortalStore`, tables prefixed `proof_portal_*`), or `PROOF_PORTAL_DATA_DIR`/`PROOF_DATA_DIR` for the file store, same as above. Set `PROOF_TEST_DATABASE_URL` to run the Postgres-backed test suites (`test/postgres.test.ts`, `test/portal-postgres.test.ts`) against a throwaway schema.

`proof serve` hardening: the publisher HTTP well-known challenge fetch (`ssrfSafeFetch` in `src/portal/verify.ts`) resolves each hostname once, rejects any non-public address, and connects directly to that validated IP (Host header / TLS SNI still set to the original hostname) so a DNS answer that changes between validation and connection can't be used to reach an internal address. The server also applies a per-source-IP token-bucket rate limit (`src/serve/rate-limit.ts`; 429 + `Retry-After` when exceeded), configurable via `ServeOptions.rateLimit`.

| Command | Purpose | Exit codes |
|---|---|---|
| `capture <url…> [--run] [--ua] [--purpose search,ai-input,ai-train] [--no-enforce] [--seal]` | Fetch URLs and capture their evidence | 2 if any URL was flagged, skipped or failed |
| `manifest --run ID` | Sign the run's manifest and chain it to the previous one | |
| `runs` | List runs and whether each is sealed | |
| `verify [--trusted-key B64]` | Check hashes, signatures, chain links and stored captures | 3 on failure |
| `revalidate [--run ID] [--no-headers] [--json]` | Re-check captures against today's signals | 4 if any capture drifted |
| `report --run ID [--format html\|json\|pdf] [--out F] [--revalidate]` | Clean-ingestion certificate plus per-URL evidence | |
| `prove <url\|capture-id> [--out F]` | Compact Merkle inclusion proof for one capture | |
| `verify-inclusion <proof.json> [--manifest F] [--trusted-key B64]` | Verify an inclusion proof offline | 3 on failure |
| `certify --run ID [--run ID…] [--dataset-hash H \| --dataset-file F] [--urls F] [--purpose P,…] [--out F] [--tar F] [--pdf F] [--hf-card README.md] [--c2pa manifest.json]` | Issue a signed clean-ingestion certificate | |
| `verify-certificate <cert.json\|bundle.tar> [--trusted-key B64] [--revocations F]` | Verify a certificate (JSON or .tar bundle) offline | 3 on failure |
| `verify-pdf <file.pdf> [--trusted-key B64] [--revocations F]` | Verify a Proof PDF's embedded signed attachment | 3 on failure |
| `verify-card <README.md> [--trusted-key B64] [--revocations F]` | Verify the certificate a dataset card's `proof` front-matter block points to, offline | 3 on failure |
| `verify-c2pa <manifest.json> [--trusted-key B64] [--revocations F]` | Verify the certificate embedded in a C2PA-shaped manifest, offline | 3 on failure |
| `certificate list \| status <id> \| revoke <id> --reason R` | List/track/revoke issued certificates | 4 if drifted, 5 if revoked |
| `keys list \| rotate [--reason R] \| revoke <id> [--reason R] [--effective-at ISO] [--external] \| revocations [--out F]` | Key rotation, revocation and signed revocation-list export | |
| `keys receipt-show` | Print the `stack-receipt/v1` signing key (product `proof`), and the `ledger keys enroll` command to register it | |
| `retention policy [--tier default\|pro\|enterprise] [--days N] \| apply [--dry-run]` | Set/apply the retention policy | |
| `hold add (--run ID \| --url-prefix P) --reason R \| list \| remove <id>` | Legal holds that block eviction | |
| `watch [--interval SEC] [--once] [--run ID] [--rate-ms MS] [--no-headers]` | Scheduled re-validation pass(es), recorded as signed drift manifests | 4 if any capture drifted |
| `anchor` | (Re)post every un-anchored manifest head to Ledger (idempotent) | |
| `serve [--port 8420]` | Read-only HTTP status API for certificates | |
| `license show [--json]` \| `license verify <token\|file>` | Inspect the current or a given license, entirely offline | |

Every `proof.fetch.captured`/`proof.manifest.signed` record posted to Ledger also carries a
signed `payload.receipt`: a `stack-receipt/v1` envelope (`src/receipt.ts`) over the record's
payload, signed with the same Ed25519 key Proof already uses for manifests/certificates
(`PROOF_KEY_DIR`/`PROOF_SIGNING_KEY`). `ledger incident` verifies it alongside every other
product's, independent of trusting Ledger's storage. Conformance vectors (validated
byte-for-byte against Ledger's Go implementation — the same signature verifies on both sides)
live in `testdata/receipts/`, copied from Ledger's `docs/receipt-spec.md`; see `test/receipt.test.ts`.

## Library / Discover integration

Discover's `ScraperEngine` takes `fetchFn: typeof fetch` in its constructor, so Proof plugs in as a fetch wrapper:

```ts
import { withProof, storeFromEnv, sealRun, loadOrCreateKey, ledgerFromEnv } from 'proof';

const store = await storeFromEnv();
const { fetch: proofFetch, capturer } = withProof(fetch, {
  userAgent: 'discovery-research-bot/0.1',
  purposes: ['search', 'ai-input'],
  onCapture: (c) => store.saveCapture(c),
  ledger: ledgerFromEnv(),
});
const scraper = new ScraperEngine(browserPool, proofFetch);
// … crawl …
await sealRun(store, capturer.runId, loadOrCreateKey('.proof/keys'), ledgerFromEnv());
```

How the hook behaves:
- It only captures `GET` requests over http(s). Other requests pass through unchanged.
- If the caller has not set a User-Agent, it presents the bot identity.
- It checks robots.txt before the request. With `enforceRobots` on (the default), a URL that robots.txt disallows, or whose robots.txt Content Signals refuse every declared purpose, is recorded as a skipped capture and a `RobotsDisallowedError` is thrown, so the fetch never happens. Skipped URLs are never counted as violations.
- It captures a clone of the response and hands the caller an unconsumed `Response`.

If you only need the evidence, call `new Capturer(opts).capture(url)` directly.

## Architecture

```
src/robots.ts      RFC 9309 parser: groups, longest-match evaluation, Content-Signal/Content-Usage lines, use= form
src/license.ts     regex detector (CC badges/links/text, rel=license, ToS links, no-AI/TDM clauses, meta tdm-reservation,
                   X-Robots-Tag noai) + optional Claude fallback ("skipped: no API key" without ANTHROPIC_API_KEY)
src/capture.ts     Capturer: robots (cached per origin; 4xx=allow all, 5xx/network=disallow all), fetch, evidence, violations
src/manifest.ts    canonical JSON, capture hashes, capturesRoot, Ed25519 sign, chain verification
src/service.ts     sealRun (build → append to store → Ledger), verifyStore
src/revalidate.ts  re-fetch robots + HEAD headers now, diff vs capture → drift findings (worsened/changed/relaxed)
src/report.ts      JSON certificate + self-contained HTML (print CSS; embedded JSON)
src/hook.ts        withProof(fetch) wrapper
src/ledger.ts      Ledger HTTP client (chain "proof": proof.fetch.captured, proof.manifest.signed); no-op without LEDGER_URL
src/receipt.ts     stack-receipt/v1 codec (self-contained TS port of Ledger's docs/receipt-spec.md; signs every record's payload)
src/store/         FileStore (JSONL) and PostgresStore (JSONB, chain-head lock on append)
src/merkle.ts      RFC 6962/9162 Merkle tree hash, audit paths and inclusion verification (SHA-256, domain-separated)
src/inclusion.ts   per-URL Merkle inclusion proofs against a signed manifest (v2: compact audit path; v1: full entry list)
src/certificate.ts signed clean-ingestion certificates: verdict + inclusion proofs + chain segment, .tar bundle, status (valid/drifted/revoked)
src/export-formats.ts HF dataset-card YAML front-matter merge + C2PA-shaped manifest, both re-verifiable offline via verify-certificate
src/pdf.ts         native PDF export (pdfkit) for certificates and reports, with the signed JSON embedded as a verifiable attachment
src/keyring.ts     key rotation (chained, proof-of-possession signed) and revocation, signed offline-verifiable revocation lists
src/retention.ts   retention tiers, legal holds, eviction to a hash-preserving tombstone (chain still verifies after eviction)
src/anchor.ts      Ledger payload/idempotency-key for a manifest head, and cross-checking the local chain against Ledger's copy
src/watch.ts       one re-validation pass over historical captures, rate-limited per origin, recorded as a signed drift manifest
src/robots-fetch.ts robots.txt fetch/cache and per-origin rate limiting shared by capture and watch
src/tar.ts         minimal deterministic ustar reader/writer for certificate bundles
src/serve/server.ts authenticated HTTP service: RBAC'd runs/reports/certificates read API, idempotent ingest, remote seal, publisher portal routes
src/serve/rbac.ts  role -> permission table for the service above
src/portal/store.ts orgs, bearer tokens (hashed), verified domains, opt-ins, ingested-capture index, audit log (file-backed; see roadmap)
src/portal/verify.ts DNS TXT / HTTPS well-known domain-control challenge and verification
src/portal/aggregate.ts k-anonymity + optional differential-privacy (Laplace) aggregation of violation signals into weekly (org, signal-type) cells
src/portal/html.ts  minimal HTML layout + strict CSP for the portal's server-rendered pages
src/discover/       Discover integration: mirrored type shapes + adapter folding browser-fetch evidence and branch decisions into Capture/manifest
```

Hashing: `captureSha256 = sha256(canonical_json(capture))`; `capturesRoot = sha256(join("\n", captureSha256…))` (v1); v2 manifests additionally sign a `merkleRoot` (RFC 6962 Merkle tree hash over `canonical_json(entry)` leaves), which is what `src/inclusion.ts` proves URLs into; `manifest.hash = sha256(prevManifestHash + "\n" + canonical_json(header))`, where `header` is the manifest body minus `entries` for v2 (v1 signs the whole body). The signature is Ed25519 over the hex hash string. Manifests carry the raw public key in base64. Use `verify --trusted-key` to pin the key. Old (v1) manifests keep verifying unchanged; `verify-inclusion`/certificates fall back to a full-entry-list proof for them since there is no Merkle root to prove an audit path against.

Violations recorded at fetch time:
- robots.txt disallow, when the URL was fetched anyway
- a Content Signal that refuses a declared purpose
- `X-Robots-Tag: noai` when the purposes include `ai-train`
- `noindex` when the purposes include `search`
- license terms or clauses that prohibit AI training, when the purposes include `ai-train`

## Tests

`npm test` runs the vitest suite. It makes no network calls; fetch is always mocked. The Postgres test runs only when `PROOF_TEST_DATABASE_URL` is set:

```bash
PROOF_TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/proof npm test
```

## Testing & hardening

Beyond `npm test`, this repo has:
- `scripts/e2e.sh` — end-to-end smoke test against a real Postgres store and a real `proof serve`
  process: capture → seal → verify → certify → verify-certificate/verify-pdf, key rotation and
  revocation (including the backdated-vs-forward-revocation distinction), retention/eviction with
  chain re-verification, the publisher portal and tenant isolation, and idempotent ingest.
  Skips cleanly (exit 0) if Postgres isn't reachable; exits non-zero on any real failure. Run it
  with `PROOF_TEST_DATABASE_URL` set, or it defaults to `postgres://postgres:postgres@localhost:5432/proof`.
- Fuzz/property tests (`test/fuzz-*.test.ts`, via `fast-check`) for Merkle inclusion proofs,
  tamper-resistance of manifests/certificates/inclusion proofs, the robots.txt and Content Signals
  parsers, the tar reader, and PDF attachment extraction — the invariant in each case is "no
  tampered/hostile input may ever verify or crash".
- `SECURITY.md` documents the threat model, the security findings fixed in this pass, and what was
  reviewed and found sound.
- `.github/workflows/ci.yml` runs typecheck, lint, `npm test` (with a Postgres service), build, and
  `scripts/e2e.sh` on every push/PR.

## Built vs roadmap

Built:
- capture layer
- regex license detection with an LLM fallback
- signed, hash-chained manifests (v1 flat capturesRoot; v2 RFC 6962 Merkle root — old v1 manifests still verify)
- verify
- drift re-validation, both on-demand (`revalidate`) and as a scheduled pass over historical captures (`watch`/`watchTick`), rate-limited per origin, recorded as a signed drift manifest chained into the same history
- JSON and HTML reports, plus a native PDF export (`report --format pdf`, or `proof verify-pdf` to check one) with the signed JSON embedded as a verifiable attachment — no more print-to-PDF
- Merkle inclusion proofs per URL (`proof prove` / `verify-inclusion`): O(log n) audit path against the signed `merkleRoot`, offline-verifiable
- signed clean-ingestion certificates (`proof certify`) bundling a run's verdict, its chain segment and every URL's inclusion proof into a portable, offline-verifiable `.tar` (or PDF) — this is the packaging format datasets/indexes attach; status tracks valid/drifted/revoked as later drift or key revocations land
- the certificate travels *with* the dataset, not next to it: `certify --hf-card README.md` merges a `proof:` block into a Hugging Face dataset card's YAML front-matter (id, issuer, dataset hash, purposes, allowed/flagged/skipped counts, the verify command, and a relative path to the full certificate JSON), keeping every other front-matter key and the card body untouched; `certify --c2pa manifest.json` emits a C2PA-*shaped* JSON manifest embedding the full signed certificate as a custom `org.proof.ingestion-certificate` assertion with sha256 hash bindings. `proof verify-card`/`verify-c2pa` re-verify either one completely offline, reusing `verify-certificate`'s logic. **Neither is a C2PA-conformant signed manifest** — no JUMBF embedding, no COSE signature, no X.509 chain — see `src/export-formats.ts` for exactly what is and isn't claimed
- key rotation and revocation: chained, proof-of-possession-signed rotation records, revocation records, and signed offline-verifiable revocation lists (`proof keys rotate|revoke|revocations`)
- retention tiers, legal hold, and eviction that replaces a capture's evidence with a hash-preserving tombstone so the chain still verifies after eviction (`proof retention`, `proof hold`)
- an authenticated HTTP service (`proof serve`): bearer-token RBAC (`admin`/`auditor`/`viewer`/`ingest`/`publisher` roles), a run/report/certificate read API, an idempotent ingest API for pushing captures and manifests from a remote crawler, and remote `seal`
- a publisher self-serve portal (`/portal/*`): publisher orgs prove control of a domain (DNS TXT or HTTPS well-known challenge), grant/revoke per-crawling-org opt-ins, and query k-anonymous, optionally differentially-private (Laplace noise) weekly violation-signal aggregates for their own verified domain only — a strict CSP HTML front end plus a JSON API, with every mutating action audit-logged
- multi-tenant isolation: every ingest/read/admin route is scoped to the authenticated org (a crawling org never sees another crawling org's runs; a publisher can only verify, list or query domains it owns; aggregate query results are further filtered to crawling orgs that have opted in to that specific domain) — covered by dedicated tests, not just code review
- a Discover integration adapter (`src/discover`): folds Discover's Playwright browser-fetch evidence and episodic link-scoring/branch decisions into the same Capture/manifest pipeline, without Discover importing Proof or vice versa
- Ledger anchoring of every manifest head (idempotent, retry-safe) and cross-checking the local chain against Ledger's copy
- file and Postgres stores (retention/eviction and meta storage covered on both)
- CLI, library and fetch hook

Not yet built (the "fully built version"):
- Deep integration with Discover's episodic *store* (only the fetch/branch-decision adapter exists; nothing persists into Discover's own database, and Discover does not call this adapter yet — that wiring lives in Discover's codebase).
- Full robots.txt edge cases: redirects to other hosts, the 500 KiB limit, and caching per RFC 9309 §2.4.
- Key transparency (e.g. publishing the keyring/revocation list to a public log) — revocation lists are signed and offline-verifiable, but distribution/discovery of them is left to the operator.
- A UI for minting/rotating portal tokens (`POST /v1/tokens` is API-only; the bootstrap admin token for a fresh `proof serve` is printed once to the console).
- Postgres-backed `PortalStore` (orgs/tokens/domains/opt-ins/ingested-capture rows are currently a single JSON file via `FilePortalStore`, not yet a store implementation parallel to `store/postgres.ts`) — fine for one `proof serve` process, not for horizontally-scaled deployments.

## LICENSING (Pro/Enterprise features)

Proof is open core. Capture, verify, revalidate and report — at any crawl volume — are free
and always will be; see [PRICING.md](PRICING.md). A small set of features on top require a
paid, offline license key: `PROOF_LICENSE` (a token) or `PROOF_LICENSE_FILE` (a path).
Verification is Ed25519-signature checking against a vendor public key compiled into the
build (`src/licensing`) — no network call, no phone-home, works air-gapped.

- **Pro** ($299/mo): `proof certify`, PDF export (`report --format pdf`, `certify --pdf`),
  `proof watch`, and the `pro` retention tier (up to 1 year).
- **Enterprise** ($15k–$50k/yr): everything in Pro, plus multi-org/tenant provisioning on
  `proof serve` (a second org onward), the `enterprise` retention tier (up to 7 years), and
  legal holds (`proof hold`).

States: **none** (no license — Community works fully, gated features are off), **valid**,
**grace** (up to 14 days past expiry — gated features keep working with a loud warning),
**expired** (gated features off). An invalid or tampered token is treated as no license, with
a warning — Proof never fails a build over a bad token, and never deletes or hides data when
a feature is off.

- `proof license show` / `proof license verify <token|file>` — inspect the current or a given
  license, entirely offline.
- A gated CLI command fails with a clear message and non-zero exit. A gated HTTP path (e.g.
  `POST /v1/orgs` past the first, on `proof serve`) responds `402` with a small JSON body
  naming the feature and the edition that unlocks it.
- Being over your licensed seat count is a warning only (`seatWarning` in `src/licensing`) —
  never a lockout.

**Issuing licenses** (for the vendor only — this needs the private signing key, which must
never be committed):

```
npm run build
node --experimental-strip-types scripts/licensegen.ts keygen --out priv.key   # keep priv.key OFFLINE
node --experimental-strip-types scripts/licensegen.ts issue --key priv.key \
    --customer "Acme Inc" --edition pro --seats 10 --days 365 > license.tok
```

`scripts/licensegen.ts` lives under `scripts/`, outside `tsconfig.json`'s `include`, so it is
never compiled into `dist/` and never ships in the published build. After generating your real
keypair, put its **public** key into `src/licensing/keys.ts`'s `prodPublicKeyB64` (the
checked-in placeholder decodes to 32 zero bytes and can never verify a real signature) and cut
a release; the private key stays with the vendor, offline, always.

The repo also carries a public **dev** keypair (`licensegen issue --key dev`) for tests. A
release build never trusts it: `src/licensing/keys.ts` only trusts it when a test calls the
exported `trustDevKeyForTesting()` (see `test/licensing.test.ts`'s
"a release build never trusts the public dev key" suite) or when `scripts/e2e.sh` runs the
CLI through `scripts/e2e-cli.mjs`, a test-only entry that makes the same in-process call. No
environment variable or config setting can enable it.

## License

Prolu Commercial License; see [LICENSE](LICENSE). The Community edition is free to use,
including commercially. Paid features need a license key from Prolu (see PRICING.md).
Redistribution is not permitted. Self-hosted: you run Proof on your own infrastructure, and
no hosted service is contacted.
